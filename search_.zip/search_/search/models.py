from django.db import models


class Data(models.Model):
    nid = models.IntegerField(primary_key=True)
    word = models.TextField(blank=True, null=True)
    book = models.TextField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'data'
