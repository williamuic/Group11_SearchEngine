from django.shortcuts import render
from search.models import Data

def search(request):
    return render(request,"search/search.html", {})

def handle(request):
    text = request.POST["Search"]
    data = Data.objects.all()
    result = []

    list_ = []
    for i in data:
        if text == i.word:
            list_ = i.book.split(',')
            if len(list_) > 10 :
                for j in range(10):
                    result.append(list_[j])
                    result.append(' ')
            else :
               for k in range(len(list_)):
                    result.append(list_[k])
                    result.append(' ')

    return render(request,"search/result.html", {"result":result})